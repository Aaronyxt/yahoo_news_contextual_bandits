# -*- coding: utf-8 -*-
'''Generic arm.'''

__author__ = "Olivier Cappé, Aurélien Garivier"
__version__ = "$Revision: 1.6 $"

class Arm:
    def __init__(self): self.expectation=1
    def draw(self): pass
