# -*- coding: utf-8 -*-
'''Generic class for posteriors'''

__author__ = "Olivier Cappé, Aurélien Garivier"
__version__ = "$Revision: 1.6 $"


class Posterior:
    ''' Generic class for posteriors, empty for the time being''' 
    def __init__(self): pass
