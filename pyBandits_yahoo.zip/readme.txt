__author__ = "Original version: Olivier Capp�, Aur�lien Garivier; Revised by Xiaotian YU"
__version__ = "$Revision: 1.00 $"
__software__ = "$Python 3.5.1"